import numpy as np
from transformers import pipeline
import librosa
from datasets import load_dataset
import json
from tqdm import tqdm

# Load the Whisper ASR pipeline
asr_pipeline = pipeline(
    "automatic-speech-recognition", model="openai/whisper-small", device=0
)

# Force transcription in English
asr_pipeline.model.config.forced_decoder_ids = asr_pipeline.tokenizer.get_decoder_prompt_ids(
    language="en", task="transcribe"
)

# Function to transcribe from a 1D numpy array
def transcribe_array(audio_array: np.ndarray, sampling_rate: int = 16000):
    # Convert to float32 if not already
    if audio_array.dtype != np.float32:
        audio_array = audio_array.astype(np.float32)

    # Whisper expects 1D mono audio with a sample rate of 16kHz
    if len(audio_array.shape) > 1:
        raise ValueError("Input audio must be a 1D array")

    # Whisper model will internally resample if needed, but 16kHz is preferred
    input_data = {"array": audio_array, "sampling_rate": sampling_rate}

    result = asr_pipeline(input_data)
    return result["text"]


def main():
    # get the dataset
    bhasaanuvaad = load_dataset("ai4bharat/WordProject", "en2indic")
    bhasaanuvaad = bhasaanuvaad.select_columns(
        ["chunked_audio_filepath", "text", "hi_text"]
    )
    # run for 100 example
    all_data = []
    for i in tqdm(range(100)):
        audio_array = bhasaanuvaad["en2indic"][i]["chunked_audio_filepath"]["array"]
        transcription = transcribe_array(audio_array, sampling_rate=16000)
        all_data.append(
            {
                "transcription": transcription,
                "actual_text": bhasaanuvaad["en2indic"][i]["text"],
            }
        )

    # create json for evaluation
    with open("output/baseline.json", "w") as f:
        json.dump(all_data, f)


if __name__ == "__main__":
    main()
