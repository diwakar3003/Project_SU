from jiwer import wer, cer
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
import json
import numpy as np
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("file_path", type=str, help="Path for output file")
args = parser.parse_args()


def evaluate_transcription(predicted_text, reference_text):
    predicted_text = predicted_text.strip().lower()
    reference_text = reference_text.strip().lower()

    # Metrics
    word_error = wer(reference_text, predicted_text)
    char_error = cer(reference_text, predicted_text)

    # BLEU Score
    reference_tokens = [reference_text.split()]
    predicted_tokens = predicted_text.split()
    bleu = sentence_bleu(
        reference_tokens,
        predicted_tokens,
        smoothing_function=SmoothingFunction().method1,
    )

    return {"WER": word_error, "CER": char_error, "BLEU": bleu}


def main():
    # read output file
    with open(args.file_path) as f:
        data = json.load(f)

    # calculate evaluation metrics for each row
    wer_score = []
    cer_score = []
    bleu_score = []
    for row in data:
        reference = row["transcription"]
        predicted = row["actual_text"]
        scores = evaluate_transcription(predicted, reference)
        wer_score.append(scores["WER"])
        cer_score.append(scores["CER"])
        bleu_score.append(scores["BLEU"])

    scores = {
        "WER": np.mean(wer_score),
        "CER": np.mean(cer_score),
        "BLEU": np.mean(bleu_score),
    }
    print("Evaluation Metrics:")
    for k, v in scores.items():
        print(f"{k}: {v:.4f}")


if __name__ == "__main__":
    main()
