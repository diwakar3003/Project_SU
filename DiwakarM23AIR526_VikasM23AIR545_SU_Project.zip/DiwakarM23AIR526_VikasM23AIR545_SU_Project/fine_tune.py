from datasets import load_dataset, Audio
from transformers import (
    WhisperForConditionalGeneration,
    WhisperProcessor,
    TrainingArguments,
    Trainer,
)
from peft import get_peft_model, LoraConfig, TaskType
import torch
import os

os.environ["WANDB_DISABLED"] = "true"

# Load processor & model
model_name = "openai/whisper-small"
processor = WhisperProcessor.from_pretrained(model_name)
base_model = WhisperForConditionalGeneration.from_pretrained(model_name)
base_model.config.forced_decoder_ids = processor.get_decoder_prompt_ids(
    language="en", task="transcribe"
)


def prepare_dataset(batch):
    """prepare dataset"""
    audio = batch["chunked_audio_filepath"]

    # Input: audio to input_features
    inputs = processor(audio["array"], sampling_rate=16000, return_tensors="pt")
    input_features = inputs.input_features.squeeze(0)

    # text to token ids
    labels = processor.tokenizer(
        batch["text"], return_tensors="pt", padding=False
    ).input_ids.squeeze(0)

    return {"input_features": input_features, "labels": labels}


def generate_dataset():
    """Module to generate dataset"""
    dataset = load_dataset("ai4bharat/WordProject", "en2indic")
    dataset = dataset["en2indic"].select(range(1000))
    dataset = dataset.map(prepare_dataset, remove_columns=dataset.column_names)
    return dataset


def data_collator(features):
    """data collator"""
    input_features = torch.stack([torch.tensor(f["input_features"]) for f in features])
    labels = [torch.tensor(f["labels"]) for f in features]

    # Pad labels
    labels = torch.nn.utils.rnn.pad_sequence(
        labels, batch_first=True, padding_value=processor.tokenizer.pad_token_id
    )

    return {"input_features": input_features, "labels": labels}


def trainer():
    """Trainer method"""
    # define Lora config for finetuning
    peft_config = LoraConfig(
        r=8,
        lora_alpha=16,
        lora_dropout=0.1,
        bias="none",
        target_modules=["q_proj", "v_proj"],
    )
    model = get_peft_model(base_model, peft_config)
    # get dataset
    training_dataset = generate_dataset()

    # Define training arguments
    training_args = TrainingArguments(
        output_dir="./whisper-finetuned",
        per_device_train_batch_size=16,
        num_train_epochs=3,
        fp16=True,
        save_steps=60,
        logging_steps=60,
        learning_rate=1e-5,
        warmup_steps=18,
        save_total_limit=2,
        push_to_hub=False,
    )

    # Initialize trainer
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=training_dataset,
        data_collator=data_collator,
        tokenizer=processor.feature_extractor,
    )

    # Train
    trainer.train()


if __name__ == "__main__":
    trainer()
