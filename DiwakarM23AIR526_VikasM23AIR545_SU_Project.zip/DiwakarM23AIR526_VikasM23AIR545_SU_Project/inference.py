from peft import PeftModel
from tqdm import tqdm
import json
from transformers import WhisperForConditionalGeneration, WhisperProcessor
import torch

# Load processor & base model
model_name = "openai/whisper-small"
processor = WhisperProcessor.from_pretrained(model_name)
base_model = WhisperForConditionalGeneration.from_pretrained(model_name)
base_model.config.forced_decoder_ids = processor.get_decoder_prompt_ids(
    language="en", task="transcribe"
)
# load peft model
peft_model_path = "whisper-finetuned/checkpoint-189"
model = PeftModel.from_pretrained(base_model, peft_model_path)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def inference():
    """module to make inference"""
    # get the dataset
    bhasaanuvaad = load_dataset("ai4bharat/WordProject", "en2indic")
    bhasaanuvaad = bhasaanuvaad.select_columns(
        ["chunked_audio_filepath", "text", "hi_text"]
    )
    # run for 100 example
    all_data = []
    for i in tqdm(range(100)):
        audio_array = bhasaanuvaad["en2indic"][i]["chunked_audio_filepath"]["array"]
        input = processor(audio_array, sampling_rate=16000, return_tensors="pt")
        input_features = input.input_features

        # Generate
        with torch.no_grad():
            predicted_ids = model.generate(input_features)

        # Decode
        transcription = processor.batch_decode(predicted_ids, skip_special_tokens=True)[
            0
        ]
        all_data.append(
            {
                "transcription": transcription,
                "actual_text": bhasaanuvaad["en2indic"][i]["text"],
            }
        )

    # create json for evaluation
    with open("output/finetuned_generation.json", "w") as f:
        json.dump(all_data, f)


if __name__ == "__main__":
    inference()
